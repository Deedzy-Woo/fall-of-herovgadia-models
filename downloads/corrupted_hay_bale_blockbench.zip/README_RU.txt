Откройте corrupted_hay_bale.bbmodel через File → Open Model. Все текстуры встроены. Мухи работают в Minecraft; это статический проект блока для просмотра.
