package com.herovgad.fallofherovgadia.check;

import com.herovgad.fallofherovgadia.*;
import com.herovgad.fallofherovgadia.client.particle.CorruptedHayFlyParticle;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.ParticleStatus;
import net.minecraft.core.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.DirectionalPlaceContext;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.phys.AABB;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import java.nio.file.*;
import java.lang.reflect.Field;
import java.util.*;

/** Development-only harness. This source set is never included in the shipped mod. */
@EventBusSubscriber(modid=FallOfHerovgadia.MODID, value=Dist.CLIENT)
public class HayRuntimeCheck {
    static boolean requested, setup, modelChecked, singleShot, pileShot;
    static int phase, ticks, singleMax, pileMax, minimalMax, coveredMax, singleSeen, pileSeen;
    static volatile String failure;
    static volatile boolean serverChecks;
    static Field particles;

    @SubscribeEvent
    public static void tick(ClientTickEvent.Post event) {
        if (!Boolean.getBoolean("fallofherovgadia.hayPreview")) return;
        Minecraft mc=Minecraft.getInstance();
        try {
            if (!requested && mc.screen instanceof TitleScreen) {
                requested=true;
                GameRules rules=new GameRules();rules.getRule(GameRules.RULE_DOMOBSPAWNING).set(false,null);
                var settings=new LevelSettings("Corrupted Hay Check",GameType.CREATIVE,false,Difficulty.PEACEFUL,true,rules,WorldDataConfiguration.DEFAULT);
                mc.createWorldOpenFlows().createFreshLevel("HayCheck_"+System.currentTimeMillis(),settings,new WorldOptions(81273L,false,false),
                    registry -> registry.registryOrThrow(Registries.WORLD_PRESET).getOrThrow(WorldPresets.FLAT).createWorldDimensions(),new TitleScreen());
            }
            if(mc.level==null || mc.player==null || mc.getSingleplayerServer()==null)return;
            if(failure!=null)throw new AssertionError(failure);
            if(!setup){
                setup=true;mc.options.pauseOnLostFocus=false;
                mc.getSingleplayerServer().execute(()->{try{serverSetup(mc);}catch(Throwable e){failure=e.toString();}});
                return;
            }
            if(!serverChecks)return;
            if(!modelChecked){checkModels(mc);modelChecked=true;}
            ticks++;
            int count=countFlies(mc);
            if(phase==0){
                singleMax=Math.max(singleMax,count);if(count>0)singleSeen++;
                if(count>0&&!singleShot&&ticks>40){shot(mc,"hay-single.png");singleShot=true;}
                if(ticks>=1200){System.out.println("HAY_CHECK_SINGLE max="+singleMax+" visibleTicks="+singleSeen);phase=1;ticks=0;mc.getSingleplayerServer().execute(()->buildPile(mc,false));}
            }else if(phase==1){
                pileMax=Math.max(pileMax,count);if(count>0)pileSeen++;
                if(count>=2&&!pileShot&&ticks>120){shot(mc,"hay-pile.png");pileShot=true;}
                if(ticks>=1200){System.out.println("HAY_CHECK_PILE max="+pileMax+" visibleTicks="+pileSeen);phase=2;ticks=0;mc.getSingleplayerServer().execute(()->buildPile(mc,true));}
            }else if(phase==2){
                if(ticks>120)coveredMax=Math.max(coveredMax,count);
                if(ticks>=240){phase=3;ticks=0;mc.options.particles().set(ParticleStatus.MINIMAL);mc.getSingleplayerServer().execute(()->buildPile(mc,false));}
            }else{
                if(ticks>120)minimalMax=Math.max(minimalMax,count);
                if(ticks>=360){
                    if(singleMax<1||pileMax<1)throw new AssertionError("No natural fly emission observed");
                    if(singleMax>2||pileMax>8||coveredMax>0||minimalMax>0)throw new AssertionError("Density/covered/quality check failed");
                    String report="PASS\nserver axes placement + item + hoe + actual loot drop: OK\nclient block models X/Y/Z + item model: OK\nsingle max="+singleMax+" nonzero ticks="+singleSeen+"\npile 3x3x2 max="+pileMax+" nonzero ticks="+pileSeen+"\ncovered max after expiry="+coveredMax+"\nminimal max after expiry="+minimalMax+"\n";
                    Files.writeString(Path.of("/workspace/work/hay-runtime-check/result.txt"),report);System.out.println("HAY_CHECK "+report);mc.stop();
                }
            }
        }catch(Throwable e){
            try{Files.writeString(Path.of("/workspace/work/hay-runtime-check/failure.txt"),e.toString());}catch(Exception ignored){}
            e.printStackTrace();mc.stop();
        }
    }
    static void serverSetup(Minecraft mc){
        var server=mc.getSingleplayerServer();ServerLevel level=server.overworld();
        level.setDayTime(6000);
        for(int x=-10;x<=12;x++)for(int z=-10;z<=12;z++){
            level.setBlock(new BlockPos(x,69,z),Blocks.STONE.defaultBlockState(),3);
            for(int y=70;y<=76;y++)level.setBlock(new BlockPos(x,y,z),Blocks.AIR.defaultBlockState(),3);
        }
        var block=ModBlocks.CORRUPTED_HAY_BALE.get();var pos=new BlockPos(0,70,0);var stack=new ItemStack(ModItems.CORRUPTED_HAY_BALE.get());
        if(ModItems.CORRUPTED_HAY_BALE.get().getBlock()!=block)throw new AssertionError("BlockItem mismatch");
        for(Direction face:Direction.values()){
            var state=block.getStateForPlacement(new DirectionalPlaceContext(level,pos,face,stack,face));
            if(state.getValue(RotatedPillarBlock.AXIS)!=face.getAxis())throw new AssertionError("Placement axis "+face);
        }
        var state=block.defaultBlockState();
        if(!state.is(BlockTags.MINEABLE_WITH_HOE))throw new AssertionError("Hoe tag missing");
        if(new ItemStack(Items.IRON_HOE).getDestroySpeed(state)<=1)throw new AssertionError("Hoe speed missing");
        level.setBlock(pos,state,3);level.destroyBlock(pos,true);
        var drops=level.getEntitiesOfClass(ItemEntity.class,new AABB(pos).inflate(1));
        if(drops.stream().noneMatch(e->e.getItem().is(ModItems.CORRUPTED_HAY_BALE.get())&&e.getItem().getCount()==1))throw new AssertionError("Loot drop missing");
        drops.forEach(e->e.discard());level.setBlock(pos,state,3);
        // Three separate orientations remain visible behind the main observation block.
        for(var axis:Direction.Axis.values())level.setBlock(new BlockPos(-5+axis.ordinal()*2,70,-4),state.setValue(RotatedPillarBlock.AXIS,axis),3);
        // Remove the display row before counting: only one hay block in the single-block phase.
        for(var axis:Direction.Axis.values())level.setBlock(new BlockPos(-5+axis.ordinal()*2,70,-4),Blocks.AIR.defaultBlockState(),3);
        var player=server.getPlayerList().getPlayer(mc.player.getUUID());player.setGameMode(GameType.CREATIVE);player.teleportTo(level,2.8,70,3.8,145,13);
        player.getInventory().setItem(0,stack.copy());player.inventoryMenu.broadcastChanges();
        serverChecks=true;System.out.println("HAY_CHECK_SERVER_OK");
    }
    static void buildPile(Minecraft mc,boolean covered){
        var level=mc.getSingleplayerServer().overworld();
        for(int x=-1;x<=3;x++)for(int z=-1;z<=3;z++)for(int y=70;y<=72;y++){
            boolean hay=x>=0&&x<3&&z>=0&&z<3&&y<72;
            level.setBlock(new BlockPos(x,y,z),hay?ModBlocks.CORRUPTED_HAY_BALE.get().defaultBlockState():(covered?Blocks.STONE:Blocks.AIR).defaultBlockState(),3);
        }
        var player=mc.getSingleplayerServer().getPlayerList().getPlayer(mc.player.getUUID());player.teleportTo(level,5.5,70,6.5,141,8);
    }
    static void checkModels(Minecraft mc){
        var end=net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(FallOfHerovgadia.MODID,"block/corrupted_hay_bale_top");
        var side=net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(FallOfHerovgadia.MODID,"block/corrupted_hay_bale_side");
        for(var axis:Direction.Axis.values()){
            var state=ModBlocks.CORRUPTED_HAY_BALE.get().defaultBlockState().setValue(RotatedPillarBlock.AXIS,axis);
            var model=mc.getBlockRenderer().getBlockModel(state);
            for(Direction face:Direction.values()){
                var quads=model.getQuads(state,face,RandomSource.create(42));
                if(quads.size()!=1||!quads.getFirst().getSprite().contents().name().equals(face.getAxis()==axis?end:side))throw new AssertionError("Baked model axis/texture "+axis+" "+face);
            }
        }
        var model=mc.getItemRenderer().getModel(new ItemStack(ModItems.CORRUPTED_HAY_BALE.get()),mc.level,mc.player,0);
        if(!model.getParticleIcon().contents().name().equals(side))throw new AssertionError("Missing item model");
        System.out.println("HAY_CHECK_CLIENT_MODELS_OK");
    }
    static int countFlies(Minecraft mc)throws Exception{
        if(particles==null){particles=ParticleEngine.class.getDeclaredField("particles");particles.setAccessible(true);}
        var map=(Map<?,?>)particles.get(mc.particleEngine);int count=0;
        for(Object q:map.values())for(Object p:(Iterable<?>)q)if(p instanceof CorruptedHayFlyParticle)count++;
        return count;
    }
    static void shot(Minecraft mc,String name){Screenshot.grab(mc.gameDirectory,name,mc.getMainRenderTarget(),component->{});}
}
