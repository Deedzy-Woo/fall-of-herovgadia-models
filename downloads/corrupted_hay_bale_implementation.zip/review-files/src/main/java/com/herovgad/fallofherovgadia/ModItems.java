package com.herovgad.fallofherovgadia;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(FallOfHerovgadia.MODID);
    public static final DeferredItem<DeferredSpawnEggItem> GHOUL_SPAWN_EGG = ITEMS.register(
            "ghoul_spawn_egg", () -> new DeferredSpawnEggItem(ModEntities.GHOUL, 44975, 7969893, new Item.Properties()));

    public static final DeferredItem<BlockItem> CORRUPTED_HAY_BALE = ITEMS.registerSimpleBlockItem(ModBlocks.CORRUPTED_HAY_BALE);

    public static void addCreativeItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey().equals(CreativeModeTabs.SPAWN_EGGS)) event.accept(GHOUL_SPAWN_EGG);
        if (event.getTabKey().equals(CreativeModeTabs.NATURAL_BLOCKS)) event.accept(CORRUPTED_HAY_BALE);
    }

    private ModItems() {}
}
