package com.herovgad.fallofherovgadia;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(Registries.PARTICLE_TYPE, FallOfHerovgadia.MODID);
    // false: never force particles past Minecraft's normal quality/distance checks.
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> CORRUPTED_SOIL_VAPOR =
            PARTICLES.register("corrupted_soil_vapor", () -> new SimpleParticleType(false));

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> CORRUPTED_HAY_FLY =
            PARTICLES.register("corrupted_hay_fly", () -> new SimpleParticleType(false));

    private ModParticles() {}
}
