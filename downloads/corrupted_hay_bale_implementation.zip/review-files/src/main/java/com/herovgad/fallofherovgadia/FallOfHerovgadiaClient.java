
package com.herovgad.fallofherovgadia;

import com.herovgad.fallofherovgadia.client.GhoulRenderer;
import com.herovgad.fallofherovgadia.client.InfectedVillagerRenderer;
import com.herovgad.fallofherovgadia.client.VillagerCorpseRenderer;
import com.herovgad.fallofherovgadia.client.particle.CorruptedSoilVaporParticle;
import com.herovgad.fallofherovgadia.client.particle.CorruptedHayFlyParticle;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

@Mod(value = FallOfHerovgadia.MODID, dist = Dist.CLIENT)
public class FallOfHerovgadiaClient {

    public FallOfHerovgadiaClient(
            IEventBus modEventBus,
            ModContainer container
    ) {
        modEventBus.addListener(this::registerRenderers);
        modEventBus.addListener(this::registerParticles);

        FallOfHerovgadia.LOGGER.info(
                "Fall of Herovgadia client initialized!"
        );
    }

    private void registerParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.CORRUPTED_SOIL_VAPOR.get(),
                CorruptedSoilVaporParticle.Provider::new);
        event.registerSpriteSet(ModParticles.CORRUPTED_HAY_FLY.get(), CorruptedHayFlyParticle.Provider::new);
    }

    private void registerRenderers(
            EntityRenderersEvent.RegisterRenderers event
    ) {

        event.registerEntityRenderer(ModEntities.DEAD_HARPY.get(), net.minecraft.client.renderer.entity.PhantomRenderer::new);
        // Обычный вурдалак
        event.registerEntityRenderer(
                ModEntities.GHOUL.get(),
                GhoulRenderer::new
        );

        // Заражённый крестьянин
        event.registerEntityRenderer(
                ModEntities.INFECTED_VILLAGER.get(),
                InfectedVillagerRenderer::new
        );

        // Труп жителя
        event.registerEntityRenderer(
                ModEntities.VILLAGER_CORPSE.get(),
                VillagerCorpseRenderer::new
        );
    }
}
