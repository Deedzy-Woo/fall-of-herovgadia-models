package com.herovgad.fallofherovgadia;

import com.herovgad.fallofherovgadia.block.CorruptedHayBaleBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(FallOfHerovgadia.MODID);
    public static final DeferredBlock<CorruptedHayBaleBlock> CORRUPTED_HAY_BALE = BLOCKS.register(
            "corrupted_hay_bale", () -> new CorruptedHayBaleBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.HAY_BLOCK)));

    private ModBlocks() {}
}
