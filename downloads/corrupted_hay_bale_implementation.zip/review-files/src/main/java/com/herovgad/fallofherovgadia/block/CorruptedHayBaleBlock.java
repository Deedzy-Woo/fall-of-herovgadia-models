package com.herovgad.fallofherovgadia.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HayBlock;
import net.minecraft.world.level.block.state.BlockState;

public final class CorruptedHayBaleBlock extends HayBlock {
    public static final MapCodec<HayBlock> CODEC = simpleCodec(CorruptedHayBaleBlock::new);

    public CorruptedHayBaleBlock(Properties properties) { super(properties); }

    @Override
    public MapCodec<HayBlock> codec() {
        return CODEC;
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        super.animateTick(state, level, pos, random);
        CorruptedHayFlyEmitter.animateTick(level, pos, random);
    }

    @Override
    public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return Blocks.HAY_BLOCK.defaultBlockState().getFlammability(level, pos, face);
    }

    @Override
    public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        return Blocks.HAY_BLOCK.defaultBlockState().getFireSpreadSpeed(level, pos, face);
    }
}
