
package com.herovgad.fallofherovgadia;

import com.herovgad.fallofherovgadia.entity.GhoulEntity;
import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import org.slf4j.Logger;

@Mod(FallOfHerovgadia.MODID)
public class FallOfHerovgadia {

    public static final String MODID = "fallofherovgadia";

    public static final Logger LOGGER = LogUtils.getLogger();

    public FallOfHerovgadia(IEventBus modEventBus, ModContainer modContainer) {

        // Подключаем настройки мода
        modContainer.registerConfig(ModConfig.Type.COMMON, Config.SPEC);

        // Регистрируем наших существ
        ModEntities.ENTITY_TYPES.register(modEventBus);
        ModSounds.SOUNDS.register(modEventBus);
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModParticles.PARTICLES.register(modEventBus);
        modEventBus.addListener(ModItems::addCreativeItems);

        // Регистрируем характеристики существ
        modEventBus.addListener(this::registerEntityAttributes);

        LOGGER.info("Fall of Herovgadia has awakened!");
    }

    private void registerEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.DEAD_HARPY.get(), com.herovgad.fallofherovgadia.entity.DeadHarpyEntity.attributes().build());

        // Характеристики обычного вурдалака
        event.put(
                ModEntities.GHOUL.get(),
                GhoulEntity.createAttributes().build()
        );

        // Характеристики заражённого крестьянина
        event.put(
                ModEntities.INFECTED_VILLAGER.get(),
                GhoulEntity.createAttributes().build()
        );
    }
}
