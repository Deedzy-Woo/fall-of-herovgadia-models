package com.herovgad.fallofherovgadia.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.ParticleGroup;
import net.minecraft.core.particles.SimpleParticleType;

import java.util.Optional;

public final class CorruptedHayFlyParticle extends TextureSheetParticle {
    public static final int GLOBAL_LIMIT = 8;
    private static final ParticleGroup GROUP = new ParticleGroup(GLOBAL_LIMIT);
    private final double anchorX, anchorY, anchorZ;
    private double targetX, targetY, targetZ;
    private int retarget;

    private CorruptedHayFlyParticle(ClientLevel level, double x, double y, double z, SpriteSet sprites) {
        super(level, x, y, z);
        anchorX = x; anchorY = y; anchorZ = z;
        lifetime = 60 + random.nextInt(41);
        quadSize = 0.025F + random.nextFloat() * 0.015F;
        gravity = 0; friction = 0.86F; hasPhysics = true;
        setSize(0.025F, 0.025F);
        pickSprite(sprites);
        chooseTarget();
    }

    private void chooseTarget() {
        targetX = anchorX + (random.nextDouble() - 0.5) * 0.85;
        targetY = anchorY + (random.nextDouble() - 0.5) * 0.55;
        targetZ = anchorZ + (random.nextDouble() - 0.5) * 0.85;
        retarget = 6 + random.nextInt(8);
    }

    @Override
    public void tick() {
        if (--retarget <= 0) chooseTarget();
        // Small, changing steering impulses; no autonomous mob/entity or AI.
        xd = Math.clamp(xd + (targetX - x) * 0.025, -0.035, 0.035);
        yd = Math.clamp(yd + (targetY - y) * 0.025, -0.025, 0.025);
        zd = Math.clamp(zd + (targetZ - z) * 0.025, -0.035, 0.035);
        super.tick();
        if (!isAlive()) return;
        // A vanilla collision can stop a particle; retire it instead of leaving a stuck insect.
        if (age > 3 && x == xo && y == yo && z == zo) { remove(); return; }
        alpha = Math.min(1.0F, Math.min(age / 4.0F, (lifetime - age) / 8.0F));
    }

    @Override public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }
    @Override public Optional<ParticleGroup> getParticleGroup() { return Optional.of(GROUP); }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Provider(SpriteSet sprites) { this.sprites = sprites; }
        @Override public Particle createParticle(SimpleParticleType type, ClientLevel level,
                double x, double y, double z, double xd, double yd, double zd) {
            return new CorruptedHayFlyParticle(level, x, y, z, sprites);
        }
    }
}
